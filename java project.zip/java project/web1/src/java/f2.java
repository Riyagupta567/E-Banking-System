import java.io.*;

import javax.servlet.*;   //for generic servlet class 
import javax.servlet.http.*;  //for getting http servlet class 

public class f2 extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String nm=req.getParameter("n1");
        pw1.println("<html><body bgcolor=skyblue>Welcome "+nm+"</body></html>"); //response from servlet
    }
}