import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;//for getting the genericservlet
import javax.servlet.http.*;//for getting httpserver
import java.sql.*;
public class f51 extends HttpServlet
{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String nm=req.getParameter("n1");
        String nm2=req.getParameter("n2");
        String nm3=req.getParameter("n3");
        String nm4=req.getParameter("n4");
        String nm5=req.getParameter("n5");
        String nm6=req.getParameter("n6");
        String nm7=req.getParameter("n7");
   //     pw1.println("<htm><body bgcolor=skyblue>Welcom "+nm+"<br> your email adress is "+nm2+"<br> and your address is "+nm3+"<br> your contect number is"+nm4+" </body></html>");
    
    try
        {
      Class.forName("oracle.jdbc.driver.OracleDriver");
      //resistring type four driver  of oracle
      Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","123") ;
            Statement stmt=con.createStatement();
           String q1="insert into detail values('"+nm+"','"+nm2+"','"+nm3+"','"+nm4+"','"+nm5+"','"+nm6+"','"+nm7+"')";
           int x=stmt.executeUpdate(q1);
           if (x>0){
               pw1.println("<htm><body bgcolor=skyblue>Name= "+nm+"<br> EmailId= "+nm2+"<br>Address= "+nm3+"<br>Contact Number= "+nm4+"<br>Password= "+nm5+"<br>Security question= "+nm5+"<br>Ans= "+nm5+" </body></html>");
           }
           else
           {
               pw1.println("<htm><body bgcolor=skyblue>Name= "+nm+"<br> EmailId= "+nm2+"<br>Address= "+nm3+"<br>Contact Number= "+nm4+"<br>Password= "+nm5+"<br>Security question= "+nm5+"<br>Ans= "+nm5+" </body></html>");

               con.close();
           }
              
      
        }
        catch(Exception e)
        {
            pw1.println(e);
        }
    }        
}