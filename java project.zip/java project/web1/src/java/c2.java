import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
//for getting a generic servlet class
// for getting the HttpServlet.
public class c2 extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException{
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String s1=req.getParameter("name");
        Cookie ob=new Cookie("nm",s1); //creating a cookie
        res.addCookie(ob); //adding cookie to clientside
        pw1.println("<form method=post action=c3><input type=submit value=submit></form>");
    }}