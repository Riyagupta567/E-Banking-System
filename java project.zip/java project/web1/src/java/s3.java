import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
//for getting a generic servlet class
// for getting the HttpServlet.
public class s3 extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException{
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        try{
            HttpSession ses=req.getSession();
            String s1=(String)ses.getAttribute("nm1");
            pw1.println("Your name is: "+s1);
        }
        catch(Exception e){
             pw1.println(e);
             
        }
    }}