import java.io.*;

import javax.servlet.*;   //for generic servlet class 
import javax.servlet.http.*;  //for getting http servlet class 

public class form1 extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String nm=req.getParameter("n1");
        String nm1=req.getParameter("n2");
        String nm2=req.getParameter("n3");
        String nm3=req.getParameter("n4");
        String nm4=req.getParameter("n5");
        String nm5=req.getParameter("n6");
        String nm6=req.getParameter("n7");
        
        pw1.println("<html><body bgcolor=skyblue>Name: "+nm+"<br> Email Id: "+nm1+"<br> Password: "+nm2+"<br> Address: "+nm3+"<br> Contact No: "+nm4+"<br> Security Question: "+nm4+"<br> Ans: "+nm6+" </body></html>");//response from servlet
    }
}