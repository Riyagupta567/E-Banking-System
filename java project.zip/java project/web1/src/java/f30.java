import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
//for getting a generic servlet class
// for getting the HttpServlet.
public class f30 extends HttpServlet{
    public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException{
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String email=req.getParameter("n1");
        String ans=req.getParameter("n6");
        
        
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","123");
            Statement stmt=con.createStatement();
            
            
           String q1="select * from detail where email='"+email+"' and ans='"+ans+"'";
            ResultSet rs=stmt.executeQuery(q1);
            if(rs.next()){
               pw1.println("<html><body bgcolor=skyblue><form method=get action=fp4> email:<input type=text name=n1><br>" +
"                       + \" new_password:<input type=text name=n8><input type=submit value=Submit></form></body></html>");
        
            }
            else{
                pw1.println("Unsuccess");
                con.close();
            }
        }
        catch(Exception e)
        {
            pw1.println(e);
        }
//        pw1.println("<html><body bgcolor=skyblue>");
//        pw1.println(" Name: "+nm+"<br>");
//        pw1.println(" Password: "+nm1+"<br>");
//        pw1.println(" Email: "+nm2+"<br>");
//        pw1.println(" Phone: "+nm3+"<br>");
//        pw1.println("</body></html>");
//        
    }
        
}