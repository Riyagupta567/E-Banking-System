import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.*;   //for generic servlet class 
import javax.servlet.http.*;  //for getting http servlet class 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/loginpage")
public class loginpage extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        
        String email=req.getParameter("e");
        String password=req.getParameter("pass");
//        pw1.println(city);
        try{
            HttpSession ses=req.getSession();
            ses.setAttribute("nm1",email);
            
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
            Statement stmt=con.createStatement();
            
            String q1="select * from reg_form where email='"+email+"' and password='"+password+"'";
//      pw1.println(q1);
           ResultSet rs = stmt.executeQuery(q1);
//           pw1.println(q1);
           if(rs.next()){
//               pw1.println("a");

                pw1.println("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"	<title>Welcome Page</title>\n" +
"	<style>\n" +
"        body \n" +
"        {\n" +
"          font-family:sans-serif; \n" +
"          background: -webkit-linear-gradient(to right, #155799, #159957); \n" +
"          background: linear-gradient(to right, #155799, #159957); \n" +
"          color:whitesmoke;\n" +
"        }\n" +
"		/* Button styles */\n" +
"		a{\n" +
"			display: flex;\n" +
"			padding: 10px 20px;\n" +
"			font-size: 16px;\n" +
"			font-weight: bold;\n" +
"			text-align: center;\n" +
"			text-decoration: none;\n" +
"			background: -webkit-linear-gradient(to right, #155799, #159957); \n" +
"          background: linear-gradient(to right, #155799, #159957); \n" +
"			border: none;\n" +
"			border-radius: 5px;\n" +
"			cursor: pointer;\n" +
"            align-items: center;\n" +
"            justify-content: center;\n" +
"            margin: 0 auto;\n" +
"           margin-bottom: 10px;\n" +
"		}\n" +
"		/* Button hover effect */\n" +
"		.button:hover {\n" +
"			background-color: #3e8e41;\n" +
"		}\n" +
"	</style>\n" +
"</head>\n" +
"<body>\n" +
"    <marquee direction=\"right\" behavior=\"alternate\" scrollamount=\"30\"><font face=\"Arial\" size=\"5\" color=\"red\" ><h1>Welcome To E banking System</h1></font></marquee>\n" +
"\n" +
"	<!-- Four buttons with different text -->\n" +
"	<a href=\"deposit-money.html\">Deposit Money</a>\n" +
"	<a href=\"withdraw-money.html\">WithDraw Money</a>\n" +
"    <a href=\"view-account.html\">Check Balance</a>\n" +
                        "<a href=\"reg-form1.html\">Logout</a>\n"+
"\n" +
"</body>\n" +
"</html>");
            }
            else{
                pw1.println("Not found");
                    con.close();
            }
            
        }
        catch(Exception e)
        {
            pw1.println(e);
        }
    }
}
