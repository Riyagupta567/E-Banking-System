import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.*;   //for generic servlet class 
import javax.servlet.http.*;  //for getting http servlet class 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/depositmoney")
public class depositmoney extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String em=req.getParameter("eml");
        String account_number=req.getParameter("account-num");
        String pin_number=req.getParameter("pin-num");
        String dep_amount=req.getParameter("amt");
        
//        pw1.println(city);
        try{
            
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
            Statement stmt=con.createStatement();
//            pw1.println(em);
String q3="select amount from deposit_money where email='"+em+"'";
//        pw1.println(q3);
            ResultSet x1=stmt.executeQuery(q3);
            String amt="";
            int x2,x3,x4;
            if(x1.next()){
                amt=x1.getString(1);
//                pw1.println(amt);
              x2=Integer.parseInt(dep_amount);    
             x3=Integer.parseInt(amt);
              x4=x2+x3;
//       pw1.println(x4);
 String q1= " UPDATE deposit_money SET amount= '"+x4+"' WHERE email='"+em+"'";
 
 int x = stmt.executeUpdate(q1);
             if (x>0){
                pw1.println("<html><body>Successfully Done</body></html>");
//                resp.sendRedirect("https://www.geeksforgeeks.org/url-rewriting-using-java-servlet/");

             }
            else{
                pw1.println("Not found");
                    con.close();
            }
            }
          
            
                    
     //pw1.println(q1);
         
            
        }
        catch(Exception e)
        {
            pw1.println(e);
        }
        //response from servlet
    }
}
