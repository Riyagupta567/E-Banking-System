import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
//for getting a generic servlet class
// for getting the HttpServlet.
public class fp4 extends HttpServlet{
    public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException{
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        
        String new_password=req.getParameter("n8");
        
        try{
            HttpSession ses=req.getSession();
            String s1=(String)ses.getAttribute("nm1");
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","123");
            Statement stmt=con.createStatement();
            
          
String q1="update reg_form set password='"+new_password+"' where email='"+s1+"'";

int x=stmt.executeUpdate(q1);
            if(x>0){
               pw1.println("<html><body bgcolor=skyblue>Password Update Successfully..!!!<br><a href=login-page.html>Go Back To Login Page</a></body></html>");
        
            }
            else{
                pw1.println("Unsuccess");
            }
        }
        catch(Exception e)
        {
            pw1.println(e);
        }
//        pw1.println("<html><body bgcolor=skyblue>");
//        pw1.println(" Name: "+nm+"<br>");
//        pw1.println(" Password: "+nm1+"<br>");
//        pw1.println(" Email: "+nm2+"<br>");
//        pw1.println(" Phone: "+nm3+"<br>");
//        pw1.println("</body></html>");
//        
    }
        
}