import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.*;   //for generic servlet class 
import javax.servlet.http.*;  //for getting http servlet class 

public class viewaccount extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String email=req.getParameter("eml");
  
        
//        pw1.println(city);
        try{
            HttpSession ses=req.getSession();
            String s1=(String)ses.getAttribute("nm1");
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
            Statement stmt=con.createStatement();
           
            String q1="select name,amount,phoneno,acc_no from reg_form join deposit_money on reg_form.email=deposit_money.email"; 
          //  pw1.println(q1);
            ResultSet rs = stmt.executeQuery(q1);
                if (rs.next()){
              pw1.println(rs.getString(1));
              pw1.println(rs.getString(2));
              pw1.println(rs.getString(3));
              pw1.println(rs.getString(3));
                    
               
             }
            else{
                pw1.println("Not found");
                    con.close();
            }
            
        }
        catch(Exception e)
        {
            pw1.println(e);
        }
        //response from servlet
    }
}
