import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.*;   //for generic servlet class 
import javax.servlet.http.*;  //for getting http servlet class 

public class regpage2 extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String name=req.getParameter("name");
        String email=req.getParameter("email");
        String password=req.getParameter("password");
        String phoneno=req.getParameter("phone-number");
        String address=req.getParameter("address");
        String state=req.getParameter("state");
        String city=req.getParameter("city");
        String pincode=req.getParameter("pin-code");
        String dob=req.getParameter("dob");
        String securityquestion=req.getParameter("security-question");
        String ans=req.getParameter("ans");
        String gender=req.getParameter("gender");
//        pw1.println(city);
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
            Statement stmt=con.createStatement();
            
            String q1="insert into reg_form values('"+name+"','"+email+"','"+password+"','"+phoneno+"','"+address+"',"
                    + "'"+state+"','"+city+"','"+pincode+"','"+dob+"','"+securityquestion+"','"+ans+"','"+gender+"')";
//            pw1.println(q1);
           int x=stmt.executeUpdate(q1);
             if (x>0){
                pw1.println("<html><body bgcolor=skyblue>Name: "+name+"<br> Email Id: "+email+"<br> Password: "+password+
                "<br> Phone: "+phoneno+"<br> Adress: "+address+"<br> Security Question: "+securityquestion+"<br>"
                        + " Ans: "+ans+" </body></html>");
            }
            else{
                pw1.println("Not found");
                    con.close();
            }
            
        }
        catch(Exception e)
        {
            pw1.println(e);
        }
        //response from servlet
    }
}
