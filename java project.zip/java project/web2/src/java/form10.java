import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
//for getting a generic servlet class
// for getting the HttpServlet.
public class form10 extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException{
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String nm=req.getParameter("n1");
        String nm1=req.getParameter("n2");
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","123");
            Statement stmt=con.createStatement();
            
            String q1="select * from detail where name='"+nm+"' and password='"+nm1+"'";
           // pw1.println(q1);
            ResultSet rs=stmt.executeQuery(q1);
            if(rs.next()){
                pw1.println("login success");
            }
            else{
                pw1.println("Not found");
            }
            con.close();
        }
        catch(Exception e)
        {
            pw1.println(e);
        }
//        pw1.println("<html><body bgcolor=skyblue>");
//        pw1.println(" Name: "+nm+"<br>");
//        pw1.println(" Password: "+nm1+"<br>");
//        pw1.println(" Email: "+nm2+"<br>");
//        pw1.println(" Phone: "+nm3+"<br>");
//        pw1.println("</body></html>");
//        
    }
        
}