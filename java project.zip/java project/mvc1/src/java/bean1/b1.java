package bean1;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
public class b1 {
    private String name;
    private String roll;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }
    public boolean insert(){
        
        return false;
    }
    public boolean InsertMethod(){
        try{
         Class.forName("oracle.jdbc.driver.OracleDriver"); 
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","123");
            Statement stmt=con.createStatement();
            String q1="insert into reg_detail values('"+name+"','"+roll+"')";
            int x=stmt.executeUpdate(q1);
            if(x>0){
                return true;
            }
            else{
                return false;
            }
        }
        catch(Exception e){
            
        }
            return false;
    }
}
