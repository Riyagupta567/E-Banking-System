import java.io.*;
import javax.servlet.*;   //for generic servlet class 
import javax.servlet.http.*;  //for getting http servlet class 
import bean1.*;
public class reg extends HttpServlet{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter pw1=res.getWriter();
        String name=req.getParameter("n1");
        String roll=req.getParameter("n2");
        
        b1 ob=new b1();
        ob.setName(name);
        ob.setRoll(roll);
        boolean result=ob.InsertMethod();
        if(result==true)
        {
            pw1.println("Success");
        }
        else{
            pw1.println("Unsuccess");
        }
    }
}